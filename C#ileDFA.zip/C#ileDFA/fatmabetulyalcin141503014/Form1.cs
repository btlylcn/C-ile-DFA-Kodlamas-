﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace fatmabetulyalcin141503014
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            cb.Text = "SEÇ";
            cb2.Text = "SEÇ";
            cb3.Text = "SEÇ";
        }


        private void butlistekle_Click(object sender, EventArgs e)
        {
            list1.Items.Add(cb.SelectedItem);
            list2.Items.Add("0");
            list3.Items.Add(cb2.SelectedItem);

            list1.Items.Add(cb.SelectedItem);
            list2.Items.Add("1");
            list3.Items.Add(cb3.SelectedItem);

            cb.Items.Remove(cb.SelectedItem);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            String[] dizi = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "R", "S", "T", "U", "V", "Y", "Z"};
            String[] bosluklu = { "-", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "R", "S", "T", "U", "V", "Y", "Z" };

            int a = Convert.ToInt32(textBox1.Text);
            for (int i = 0; i < a; i++)
            {
                cb.Items.Add(dizi[i]);
            }
            for (int i = 0; i <= a; i++)
            {
                cb2.Items.Add(bosluklu[i]);
                cb3.Items.Add(bosluklu[i]);
            }

        }

        private void list1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = (sender as ListBox).SelectedIndex;

            list1.SelectedIndex = index;
            list2.SelectedIndex = index;
            list3.SelectedIndex = index;
        }
        private void list2_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = (sender as ListBox).SelectedIndex;

            list1.SelectedIndex = index;
            list2.SelectedIndex = index;
            list3.SelectedIndex = index;
        }

        private void list3_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = (sender as ListBox).SelectedIndex;

            list1.SelectedIndex = index;
            list2.SelectedIndex = index;
            list3.SelectedIndex = index;
        }
        private void buttextekle_Click(object sender, EventArgs e)
        {
            
            textBox2.Text += list1.SelectedItem.ToString();
            textBox3.Text += list2.SelectedItem.ToString();
            textBox4.Text += list3.SelectedItem.ToString();
        }

        private void butaciklama_Click(object sender, EventArgs e)
        {
           faciklama frm = new faciklama();
           frm.ShowDialog();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

       
    }
}
