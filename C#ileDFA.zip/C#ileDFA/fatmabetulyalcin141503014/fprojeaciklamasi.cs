﻿using System;

namespace fatmabetulyalcin141503014
{
    internal class fprojeaciklamasi
    {
        internal void ShowDialog()
        {
            throw new NotImplementedException();
        }
    }
}